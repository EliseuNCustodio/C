#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    printf("digite sua idade\n");
    scanf("%i",&i);
    if ("i>=18 && i<=67")
    {
        printf("voce esta autorizado para doar sangue\n");
    }
    else
        printf("sua idade nao te possibilita doar sangue\n");
}
